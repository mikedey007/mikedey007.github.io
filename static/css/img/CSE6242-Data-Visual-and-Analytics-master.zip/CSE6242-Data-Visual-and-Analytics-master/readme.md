#CSE6242-Data Visual and Analytics

The are four homeworks in this course which focus on different topics.

1. HW1 - Collecting and visualizing data, SQLite, D3 warmup, OpenRefine 
2. HW2 - D3 Graphs and visualization
3. HW3 - Hadoop, Spark, Pig and Pandas
4. HW4 - Random Forest and Weka
